"""
IPAD自动化测试
肖子淅
日期：2022年05月11日
"""
from appium import webdriver
import time
import unittest

import page.login_page
from page import base
from page import jingxuan_page
from page.login_page import LoginPage
from page.BasePage import BasePage
from page.wode_page import MyPage
from page.jingxuan_page import JingxuanPage

class wo_test(unittest.TestCase):

    @classmethod
    def setUpClass(cls) :
        cls.driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", base.dev2)
        time.sleep(10)
        # 使用子类之前一定要初始化
        cls.LoginPage = LoginPage(cls.driver)
        cls.MyPage = MyPage(cls.driver)
        cls.driver.implicitly_wait(5)

    @classmethod
    def tearDownClass(cls):
        cls.driver.close_app()




