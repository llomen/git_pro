from appium import webdriver
import time
import unittest
from page import base
import HTMLTestRunner,logging
from jingxuan import jingxuan
from HTMLTestRunner import HTMLTestRunner
from page.jingxuan_page import JingxuanPage



now = time.strftime("%Y-%m-%d_%H_%M_%S",time.localtime())

class Tests(unittest.TestCase):

    # @classmethod
    # def setUpClass(cls) :
    #     cls.driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", base.dev2)
    #     time.sleep(10)
    #     cls.JingxuanPage = JingxuanPage(cls.driver)
    #
    #
    # @classmethod
    # def tearDownClass(cls):
    #     pass
    def setUp(self) -> None:                    # 这是测试用例执行前的准备动作
        self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',base.dev2)
        self.driver.implicitly_wait(5)                  #隐式等待 五秒

    def tearDown(self) -> None:         # 这是测试用例执行结束后的动作
        self.driver.close_app()         # 关闭App

    def jingxuan(self):                   # 用例实例化
        pass


if __name__ == '__main__':

    testsuite = unittest.TestSuite()
    testsuite.addTest(Tests("jingxuan"))

    # -------生成hmtl报告-------------
    #html报告保存路径
    HTMLfilepath = r'/Users/xiaozixi/Desktop/自动化测试/iPad-AutoTest/Function' + '/' + now + r"_result.html"
    print("HTML报告生成路径：", HTMLfilepath)
    fp = open(HTMLfilepath, 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(
            stream = fp,
            title = 'ipad自动化测试报告',
            description = '测试结果描述'
    )

    #-------------------------------------------------导出日志-------------------------------------------------

    # log日志保存路径
    Logfilepath = r'/Users/xiaozixi/Desktop/自动化测试/iPad-AutoTest/Function' + '/' + now + r"_result.log"           # 保存路径，文件名字为：时间_result.log

    print("log日志生成路径: ",Logfilepath)               #输出日志路径

    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S',
                        filename=Logfilepath,
                        filemode='w')
    logger = logging.getLogger()
    logger.info(testsuite)

    runner.run(testsuite)       #执行测试套件
    fp.close()
