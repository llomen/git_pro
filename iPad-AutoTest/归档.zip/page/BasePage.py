"""
IPAD自动化测试
肖子淅
日期：2022年04月27日
"""
import time

from  selenium.webdriver.support.wait import WebDriverWait
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import image_match


class BasePage(object):
    def __init__(self, driver):
        self.driver = driver

    def find_ele(self, loc):
        return self.driver.find_element_by_ios_class_chain(loc)

    def find_ele_xpath(self, loc):
        return self.driver.find_element_by_xpath(loc)

    def click_ele(self, loc):
        self.find_ele(loc).click()
        time.sleep(5)

    def click_ele_xpath(self, loc):
        self.find_ele_xpath(loc).click()
        time.sleep(5)

    def send_keys(self,loc,vaule):
        self.find_ele(loc).clear()
        time.sleep(5)
        self.find_ele(loc).send_keys(vaule)
        time.sleep(5)

    def hide_keyborad(self):
        self.click_ele('**/XCUIElementTypeButton[`label == "隐藏键盘"`]')
        time.sleep(5)

    def search_enter(self):
        self.driver.tap([(1000, 630)], 10)
        time.sleep(10)







