"""
IPAD自动化测试
肖子淅
日期：2022年04月27日
"""
import time
from page.BasePage import BasePage
import image_match
import page.wode_page





class LoginPage(BasePage):
    # 登录/注册按钮
    chain1 = '**/XCUIElementTypeButton[`label == "登录/注册"`]'

    # 快捷登录
    chain2 = '**/XCUIElementTypeStaticText[`label == "快捷登录"`]'

    # 登录按钮
    chain3 = '**/**[`label == "登 录"`]'
    xpath3 = '//XCUIElementTypeStaticText[@name="登 录"]'
    point3 = [(533, 451)]
    classname = '登 录'
    image_path = '../img/login_btn.PNG'

    # 个人信息保护勾选框
    chain4 = '**/XCUIElementTypeButton[`label == "mg checkbox"`]'

    # 关闭快捷登录页面
    chain5 = '**/XCUIElementTypeButton[`label == "cancel login"`]'

    # 使用其他账号登录
    chain6 = '**/XCUIElementTypeButton[`label == "使用其他账号登录"`]'

    # 手机号登录-手机号输入框
    chain7 = '**/XCUIElementTypeTextField[`value == "请输入手机号"`]'

    # 默认归属地
    chain8 = '**/XCUIElementTypeStaticText[`label == "中国+86"`]'

    # 验证码输入框
    chain9 = '**/XCUIElementTypeTextField[`value == "请输入验证码"`]'

    # 获取验证码按钮
    chain10 = '**/XCUIElementTypeButton[`label == "获取校验码"`]'

    # 账号登录按钮
    chain11 = '**/XCUIElementTypeButton[`label == "账号登录"`]'

    # 账号注册按钮
    chain12 = '**/XCUIElementTypeButton[`label == "注册"`]'

    # 其他登录方式
    chain13 = '**/XCUIElementTypeStaticText[`label == "其他登录方式"`]'

    # 微信登录
    chain14 = '**/XCUIElementTypeButton[`label == "icon wechat login"`]'

    # 微博登录
    chain15 = '**/XCUIElementTypeButton[`label == "icon weibo login"`]'

    # qq登录
    chain16 = '**/XCUIElementTypeButton[`label == "icon qq login"`]'

    # 邮箱登录
    chain17 = '**/XCUIElementTypeButton[`label == "icon mail login"`]'

    # APPle id登录
    chain18 = '**/XCUIElementTypeButton[`label == "share Apple"`]'

    # 邮箱登录页面-邮箱登录
    chain19 = '**/XCUIElementTypeStaticText[`label == "邮箱登录"`]'

    # 邮箱登录页面-返回按钮
    chain20 = '**/XCUIElementTypeButton[`label == "mine back"`]'

    # 邮箱登录页面-关闭按钮
    chain21 = '**/XCUIElementTypeButton[`label == "cancel login"`]'

    # 邮箱登录页面 邮箱地址输入框
    chain22 = '**/XCUIElementTypeTextField[`value == "请输入邮箱地址"`]'

    # 邮箱登录页面 邮箱密码输入框
    chain23 = '**/XCUIElementTypeSecureTextField[`value == "请输入密码"`]'

    # 邮箱登录页面 忘记密码
    chain24 = '**/XCUIElementTypeStaticText[`label == "忘记密码"`]'

    # 快捷登录登录按钮
    point25 = [(385, 475)]

    #设置
    chain25 = '**/XCUIElementTypeStaticText[`label == "设置"`]'

    #退出登录
    chain26 = '**/XCUIElementTypeButton[`label == "退出登录"`]'




    def mail_login(self,mail,mail_secret):
        self.send_keys(self.chain22,mail)
        self.send_keys(self.chain23,mail_secret)
        self.hide_keyborad()
        self.click_ele(self.chain4)
        #self.click_ele(self.chain3)
        #self.driver.find_element_by_xpath(self.xpath3).click()
        #self.driver.find_element_by_name(self.classname).click()
        #self.driver.find_element_by_image(self.image_path).click()
        self.driver.tap(self.point3, 1000)
        time.sleep(10)


    def into_mail_login(self):
        "邮箱登录之前存在快捷登录"
        self.click_ele(self.chain1)
        self.click_ele(self.chain6)
        self.click_ele(self.chain17)

    def quick_login(self):
        self.click_ele(self.chain4)
        self.driver.tap(self.point25,1000)
        time.sleep(5)


    def logout(self):
        self.driver.swipe(20, 700, 20, 400, 1000)
        self.click_ele(self.chain25)
        self.driver.swipe(800,700,800,400, 10000)
        self.click_ele(self.chain26)











